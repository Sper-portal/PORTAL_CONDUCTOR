PORTAL DEL CONDUCTOR — MEJORA DE TRAMOS HORARIOS

- En Control Horario se muestran todos los tramos guardados del día seleccionado.
- Cada tramo se puede editar o eliminar individualmente.
- Corregir un tramo actualiza ese registro existente; no crea un duplicado.
- Tras finalizar una jornada, los campos de entrada manual quedan en 00:00 para poder introducir otro tramo sin arrastrar las horas anteriores.
- Los registros de horas existentes se conservan.

Proyecto fuente ZIP; no es un APK. Recomendado probar primero con una copia de seguridad de los datos.


FORMATO DE HORAS — MOSTRAR HORAS Y MINUTOS
Se cambió únicamente la función de presentación hoursText(min): ahora convierte la duración en minutos a horas y minutos exactos (por ejemplo, 2 h 51 min en lugar de 2.85 h). Los cálculos internos y los registros se mantienen en minutos; no se modifica la facturación ni los datos guardados.
