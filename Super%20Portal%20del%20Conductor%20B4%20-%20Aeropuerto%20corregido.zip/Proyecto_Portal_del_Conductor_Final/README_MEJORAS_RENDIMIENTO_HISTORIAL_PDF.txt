MEJORAS AÑADIDAS EN ESTA ACTUALIZACIÓN

- Indicadores compactos en Calculadora: facturación por hora, media por viaje y facturación por kilómetro.
- El indicador €/hora se actualiza cada minuto mientras la pantalla de Calculadora está abierta y también al registrar cambios en viajes.
- El indicador €/viaje se actualiza con los viajes guardados del día.
- Registro opcional de odómetro inicial y final dentro de Control de jornada > Gasolina, guardado por fecha.
- Cálculo de kilómetros recorridos y facturación por kilómetro cuando existen lecturas válidas.
- Informe general con media por viaje, facturación por hora, kilómetros y facturación por kilómetro.
- Botones para imprimir/guardar el informe como PDF (seleccionar «Guardar como PDF» en el diálogo de impresión) y compartir/copiar el informe.
- Navegación de fechas y resúmenes ampliada para consultar hasta 18 meses hacia atrás.
- Los registros existentes no se borran por esta actualización. Se recomienda guardar una copia de seguridad antes de actualizar.

Nota: los nuevos campos y cálculos se han validado sintácticamente. La visualización final debe comprobarse en el teléfono real antes de darla por aprobada.
