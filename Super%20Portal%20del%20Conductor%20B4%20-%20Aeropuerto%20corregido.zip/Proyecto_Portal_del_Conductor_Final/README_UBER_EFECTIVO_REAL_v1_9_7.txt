PORTAL DEL CONDUCTOR - v1.9.7

Cambio único: efectivo real para viajes de Uber pagados en efectivo.
- El campo principal conserva el importe original del viaje.
- Al elegir Uber > Efectivo aparece una segunda ventana con el efectivo real precargado con el importe original.
- El usuario puede corregirlo antes de guardar.
- La facturación del viaje y el cálculo de comisión siguen usando el importe original.
- El resumen diario/semanal/mensual de efectivo usa el importe real registrado solo para Uber en efectivo.
- Uber con tarjeta y todas las demás plataformas conservan el flujo anterior.

No se han cambiado otras funciones de la aplicación.


V1.9.8: efectivo real configurable para viajes en efectivo de Bolt, Uber y Cabify. Propinas editables desde la lista de viajes para todas las plataformas, con resumen separado.
