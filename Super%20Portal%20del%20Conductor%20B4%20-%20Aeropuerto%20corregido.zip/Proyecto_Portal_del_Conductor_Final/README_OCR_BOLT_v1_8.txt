Portal del Conductor v1.8 — OCR de Bolt

Basado en la versión 1.7 Coche fijo. El botón de cámara usa Tesseract.js para leer el importe junto a “Total”.
Cuando reconoce “No cobrar al pasajero” o “Pago a través de la app”, informa que parece tarjeta; cuando reconoce “Cobrar al pasajero”, informa que parece efectivo. Si detecta texto de compensación, indica que se usa el importe TOTAL de Bolt, evitando sumar manualmente los importes parciales.
Importante: el tipo de pago sigue seleccionándose manualmente en la ventana existente al guardar el viaje, tal como pidió el usuario. Después de confirmar el pago, el código existente limpia el importe y vuelve a mostrar la calculadora preparada para el siguiente viaje.
Requiere conexión a Internet para cargar Tesseract.js desde CDN. OCR no probado en el dispositivo real; revisar siempre el importe detectado.
