PORTAL DEL CONDUCTOR — v2.0 BARRA NEÓN

Cambios visuales limitados:
- Eliminado el bloque duplicado “Accesos directos” de la pantalla principal.
- Conservada la navegación inferior con Calculadora, Control, Facturación, Informe y Ajustes.
- Aplicado estilo neón futurista con iconos y resplandor por sección.

No se han cambiado deliberadamente los cálculos ni la lógica de viajes.
Prueba esta versión en la app antes de sustituir la copia anterior.
