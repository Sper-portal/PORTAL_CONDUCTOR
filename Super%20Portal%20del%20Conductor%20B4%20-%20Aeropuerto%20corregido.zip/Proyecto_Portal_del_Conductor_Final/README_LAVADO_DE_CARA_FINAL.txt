PROYECTO PORTAL DEL CONDUCTOR FINAL — LAVADO DE CARA

Cambios de esta versión:
- Rediseño visual de los botones Bolt, Uber, Cabify y Privados con forma de cápsula, volumen, reflejos y neón manteniendo los colores de cada plataforma.
- Rediseño del botón de aeropuerto con avión, detalles azules luminosos y texto de comisión/tasa.
- Se conservan las funciones originales de alta de viajes y la navegación.
- No se han cambiado cálculos ni estructura de datos de los viajes.

Nota: es una actualización de la interfaz HTML. Debe abrirse y probarse en el dispositivo antes de sustituir la versión que se usa a diario.
