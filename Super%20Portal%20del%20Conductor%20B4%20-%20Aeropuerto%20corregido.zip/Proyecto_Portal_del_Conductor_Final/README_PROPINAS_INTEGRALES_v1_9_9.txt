Portal del Conductor v1.9.9 - Propinas integrales

Cambio aplicado sobre la versión 1.9.8:
- Las propinas registradas se suman íntegramente a la facturación diaria y al total de la plataforma del viaje, para Bolt, Uber, Cabify y Privados.
- Las propinas se muestran por separado.
- La comisión se calcula sobre la base de facturación anterior a las propinas; no se aplica comisión a las propinas.
- Los resúmenes semanales, mensuales e informes acumulan la facturación con propinas y la comisión sin propinas.
- Se mantiene la lógica de efectivo real existente para Bolt, Uber y Cabify.

Pendiente de validación en la app instalada: probar un viaje Bolt de 10,00 € netos y añadir 1,00 € de propina; el total de Bolt/facturación debe subir a 11,00 €, mientras la comisión debe permanecer igual que antes de añadir la propina.
