ACTUALIZACIÓN: PERFILES DE NÓMINA Y REFRESCO

- Se incorporan tres perfiles: Todo en nómina; Nómina + comisión en efectivo; Nómina variable + efectivo fijo.
- Salario base, tipo de comisión, porcentaje, mínimo, efectivo fijo e IRPF son editables.
- La vista previa de nómina recalcula al editar esos campos.
- La pantalla mensual usa la configuración salarial guardada para ese mes cuando existe.
- Al guardar Ajustes se registra una copia de los parámetros salariales para el mes actual.
- El botón de aeropuerto toma el porcentaje y la tasa desde Ajustes, en vez de mostrar valores fijos.
- La navegación entre periodos vuelve a renderizar los cálculos de la pantalla.

IMPORTANTE: antes de sustituir la versión de uso diario, probar en el dispositivo con datos de copia de seguridad, especialmente los tres perfiles, el cambio de mes y la corrección de viajes antiguos. Los resultados de nómina son estimaciones y no sustituyen una nómina oficial.
