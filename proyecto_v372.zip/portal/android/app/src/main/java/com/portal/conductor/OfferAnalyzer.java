package com.portal.conductor;

import java.math.BigDecimal;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Lee el texto de una oferta (Bolt/Uber/Cabify) y calcula si compensa. Sin dependencias de Android. */
public class OfferAnalyzer {

    public static class Params {
        public double minHour = 15, minKm = 1.0, maxPickup = 5.0, commission = 0, tolPct = 15, tolPickup = 1.0;
        public boolean includePickup = true;
        public BoltCfg bolt = new BoltCfg();     // estimacion de Bolt cuando la oferta no trae precio
        public long nowMs = 0;                   // v3.20-cp: hora (ms) para decidir la punta de la zona por codigo postal; 0 = ahora
        public boolean weekendNow = false;       // v3.15h: \u00abahora es hora punta\u00bb para la zona actual (lo decide quien llama con isWeekend)
        public int manualKind = -1;              // v3.37: zona de la recogida elegida a mano en el aviso (0 baja, 1 media, 2 alta; -1 = ninguna)
        public String manualSig = "";            // v3.37: huella de la oferta (sin zona) a la que vale esa eleccion; si no coincide, se ignora
        public List<StreetMemory.Entry> streets = null;   // v3.57: calles guardadas («Calles limitrofes»); null = ninguna
        public boolean noStreets = false;                 // v3.57: true = no mirar las calles guardadas (para calcular la zona «de la ubicacion» que se ofrece como boton)
    }

    public static class Result {
        public boolean offer;
        public String verdict = "DATA";           // OK, NO, DATA
        public double price = -1, tripKm = -1, tripMin = -1, pickupKm = -1, pickupMin = -1, perHour = -1, perKm = -1;
        public String ocrFix = "";                // v3.49: lo que se corrigio al leer por imagen (precio entero, coma de los km, 0 km)
        public String reason = "";
        public boolean orderAssumed;
        public String why = "";
        public boolean acceptSeen, unreadable;
        public boolean booking;                   // v3.62: la oferta lleva la etiqueta «Reservado» (una reserva): el cartel lo dice
        public boolean assignOffer;               // v3.62: el boton de la oferta es «Asignar» (no cuenta como viaje salvo que la aceptes)
        public int stH = -1, stK = -1, stP = -1;   // 0 verde, 1 naranja, 2 rojo, -1 sin dato
        // ---- estimacion de Bolt (solo si la oferta no trae precio) ----
        public boolean isBolt, estimated, estWeekend, estMinApplied;   // estWeekend = franja de hora punta ahora
        public double estGross = -1, estComm = -1, estNet = -1, estMult = 1, estOfferMult = -1;
        public double estNetLo = -1, estNetHi = -1;                     // rango (viajes cortos con demanda); -1 si no hay rango
        public boolean estRange;
        public double estAlt = -1;                                      // neto si la hora punta contara (solo si hay franja punta y NO se aplica); -1 si no
        public boolean estPeakUsed;                                     // la tarjeta de punta se uso de verdad en el calculo
        public double estDisc = 0;                                      // v3.34: descuento de viaje largo con demanda aplicado (%)
        public String estEvent = "";                                    // v3.34: lugar de evento de la oferta (sin descuento)
        public boolean estPeakShort;                                    // v3.34: es hora punta pero el viaje es largo (tarifa de valle)
        public double estAdj = 0;                                       // v3.58: ajuste por distancia aplicado (%, con signo: + sube y - baja la tarjeta)
        public double estFine = 0;                                      // ajuste fino de demanda aplicado (%)
        public double estCommPct = -1;
        public String estAirport = "";              // "" | "pickup" (recogida en el aeropuerto) | "dest" (viaje hacia el aeropuerto)
        public double estFee = 0;                   // tasa del aeropuerto restada antes de la comision
        public String estCat = "";                  // v3.46: categoria de la oferta ("", "comfort", "xl" o "premium")
        public int estZone = 1;                     // zona de la recogida: 0 baja, 1 media, 2 alta
        public String estArea = "";                 // nombre de la zona dibujada donde se detecto la ubicacion
        public String estZoneSrc = "";              // "area" (dibujada) | "default" (fuera de tus zonas) | "forced" (forzada en Ajustes) | "postal" (codigo postal) | "manual" (elegida por ti en el aviso)
        public String estCpUnlisted = "";           // v3.37: codigo postal de la recogida que NO esta en ninguna lista de Ajustes (se uso la ubicacion); "" si no hay
        public int estCpKind = -1;                  // v3.49: zona que dice el codigo postal de la recogida cuando manda la zona pintada y es distinta (-1 si no); se ofrece como boton
        public String baseSig = "";                 // v3.37: huella de la oferta SIN la zona (viaje y recogida)
        public double estNetAuto = -1;              // v3.37: neto con la zona de la ubicacion (sin tu eleccion); -1 si no hay estimacion
        public int zoneAuto = -1;                   // v3.37: zona que sale de la ubicacion; -1 si no hay botones de zona
        public int[] zoneKinds = new int[0];        // v3.37: zonas que se pueden elegir en el aviso (0 baja, 1 media, 2 alta); vacio = no hay duda que resolver
        public double[] zoneNets = new double[0];   // v3.37: neto estimado con cada una de ellas
        public String pickStreet = "", pickNum = "", pickCp = "";   // v3.57: direccion de la RECOGIDA leida de la tarjeta (para guardar la zona que elijas)
        public String memKey = "";                                    // v3.57: clave de la calle guardada que se uso ("" = ninguna)
    }

    // =====================================================================
    //  Estimacion del precio de Bolt cuando la oferta NO muestra el precio (v3.15h).
    //  Todos los valores son ESTIMACIONES editables por el conductor, NO son tarifas oficiales de Bolt.
    //  Ocho tarjetas: zona baja / media / alta (de la RECOGIDA, nunca del destino) x valle / punta, mas las dos del aeropuerto (recogidas).
    //  La demanda de la oferta multiplica todo. Las franjas de hora punta las define el conductor (una lista para media y baja, otra para alta).
    // =====================================================================

    /** Zonas: 0 baja, 1 media, 2 alta. */
    public static final int Z_LOW = 0, Z_MID = 1, Z_HIGH = 2;

    public static String zoneName(int k) { return k == Z_HIGH ? "alta" : (k == Z_LOW ? "baja" : "media"); }

    /** Una tarjeta de precios: inicial + km * precioKm + min * precioMin, nunca menos que la minima (0 = sin minima). */
    public static class Card {
        public double base, perKm, perMin, minFare;
        public Card() { }
        public Card(double base, double perKm, double perMin, double minFare) { this.base = base; this.perKm = perKm; this.perMin = perMin; this.minFare = minFare; }
        public Card copy() { return new Card(base, perKm, perMin, minFare); }
    }

    /** Minutos de una semana (de lunes 00:00 a domingo 24:00). */
    public static final int WEEK_MIN = 10080;

    /**
     * Franja de hora punta: unos dias de la semana (days: bit 0 = lunes ... bit 6 = domingo) desde la hora "a" hasta la hora "b" (minutos del dia, 0..1440).
     * Si "b" es menor o igual que "a", la franja acaba al dia siguiente (por ejemplo jueves 17:00 -> 02:00 del viernes). a = 0 y b = 1440 es el dia entero.
     */
    public static class Slot {
        public boolean on = true;
        public int days, a, b;
        public Slot() { }
        public Slot(int days, int a, int b) { this.days = days; this.a = a; this.b = b; }
        public Slot copy() { Slot s = new Slot(days, a, b); s.on = on; return s; }
        public int length() { return b > a ? b - a : b + 1440 - a; }
        /** true si el minuto de la semana w (0..10079) cae dentro: el principio cuenta, el final no. */
        public boolean contains(int w) {
            int len = length();
            for (int d = 0; d < 7; d++) {
                if ((days & (1 << d)) == 0) continue;
                int st = d * 1440 + a;
                int x = w - st;
                if (x < 0) x += WEEK_MIN;
                if (x >= 0 && x < len) return true;
            }
            return false;
        }
    }

    private static final int WEEKDAYS = 31, WEEKEND = 96, FRIDAY = 16;     // lunes a viernes / sabado y domingo / viernes

    /** Franjas de hora punta iniciales de zona media y baja: lunes a viernes 07:00-10:00 y 17:00-20:00, sabado y domingo todo el dia. */
    public static List<Slot> defaultSlots() {
        List<Slot> l = new ArrayList<Slot>();
        l.add(new Slot(WEEKDAYS, 7 * 60, 10 * 60));
        l.add(new Slot(WEEKDAYS, 17 * 60, 20 * 60));
        l.add(new Slot(WEEKEND, 0, 1440));
        return l;
    }

    /** Zona alta: igual, pero por la manana empieza a las 08:00 (visto el 29-10) y el viernes sigue de 20:00 a 24:00 (visto el 13-11); sin confirmar. */
    public static List<Slot> defaultSlotsHigh() {
        List<Slot> l = new ArrayList<Slot>();
        l.add(new Slot(WEEKDAYS, 8 * 60, 10 * 60));
        l.add(new Slot(WEEKDAYS, 17 * 60, 20 * 60));
        l.add(new Slot(FRIDAY, 20 * 60, 1440));
        l.add(new Slot(WEEKEND, 0, 1440));
        return l;
    }

    /** v3.51: la zona alta de fabrica de la v3.50 y anteriores (para pasar a la nueva a quien no la cambio). */
    public static List<Slot> defaultSlotsHighOld() {
        List<Slot> l = new ArrayList<Slot>();
        l.add(new Slot(WEEKDAYS, 8 * 60, 10 * 60));
        l.add(new Slot(WEEKDAYS, 17 * 60, 20 * 60));
        l.add(new Slot(WEEKEND, 0, 1440));
        return l;
    }

    /** v3.51: dos listas de franjas iguales (mismos dias, horas y estado). */
    public static boolean sameSlots(List<Slot> a, List<Slot> b) {
        if (a == null || b == null || a.size() != b.size()) return false;
        for (int i = 0; i < a.size(); i++) {
            Slot x = a.get(i), y = b.get(i);
            if (x == null || y == null || x.on != y.on || x.days != y.days || x.a != y.a || x.b != y.b) return false;
        }
        return true;
    }

    /** v3.51: copia de una lista de franjas. */
    public static List<Slot> copySlots(List<Slot> a) {
        List<Slot> l = new ArrayList<Slot>();
        if (a != null) for (Slot s : a) if (s != null) l.add(s.copy());
        return l;
    }

    /** Una zona dibujada a mano: un poligono (puntos [latitud, longitud] en orden) de zona alta, media o baja. */
    public static class Area {
        public String name = "";
        public int kind = Z_HIGH;
        public List<double[]> pts = new ArrayList<double[]>();
        public Area() { }
        public Area(String name, List<double[]> pts) { this.name = name; this.pts = pts; }
        public Area(String name, int kind, List<double[]> pts) { this.name = name; this.kind = kind; this.pts = pts; }
        public Area copy() {
            List<double[]> p = new ArrayList<double[]>();
            for (double[] q : pts) p.add(new double[]{q[0], q[1]});
            return new Area(name, kind, p);
        }
        /** Punto dentro del poligono (regla par-impar; la orilla puede salir en cualquiera de los dos lados). */
        public boolean contains(double lat, double lon) {
            boolean in = false;
            for (int i = 0, j = pts.size() - 1; i < pts.size(); j = i++) {
                double yi = pts.get(i)[0], xi = pts.get(i)[1], yj = pts.get(j)[0], xj = pts.get(j)[1];
                if (((yi > lat) != (yj > lat)) && (lon < (xj - xi) * (lat - yi) / (yj - yi) + xi)) in = !in;
            }
            return in;
        }
    }

    /** Las zonas dibujadas. Fuera de todas ellas vale la zona por defecto de Ajustes (media de fabrica). */
    public static class Zone {
        public List<Area> good = new ArrayList<Area>();   // sin zonas al principio
        // v3.20-cp: codigos postales de la RECOGIDA por tipo de zona. De fabrica (lista del conductor): alta = norte y noroeste; media = dentro de la M-30; baja = este y sur
        public List<String> postH = new ArrayList<String>(java.util.Arrays.asList("28023 28033 28034 28035 28042 28043 28049 28050 28055 28100 28108 28109 28220 28221 28222 28223 28224 28230 28231 28232 28250 28701 28702 28703 28760 28761 28762".split(" ")));
        public List<String> postM = new ArrayList<String>(java.util.Arrays.asList("28001 28002 28003 28004 28005 28006 28007 28008 28009 28010 28012 28013 28014 28015 28016 28020 28028 28029 28036 28039 28045 28040 28046 28048".split(" ")));
        public List<String> postL = new ArrayList<String>(java.util.Arrays.asList("28022 28037 28801 28802 28803 28804 28805 28806 28807 28821 28822 28823 28830 28850 28018 28019 28021 28025 28026 28030 28031 28032 28038 28041 28044 28047 28054 28901 28902 28903 28904 28905 28906 28907 28911 28912 28913 28914 28915 28916 28917 28918 28919 28921 28922 28923 28924 28925 28931 28932 28933 28934 28935 28936 28937 28938 28940 28941 28942 28943 28944 28945 28946 28947 28980 28981 28982 28983 28984 28300 28311 28312 28320 28341 28342 28343 28011 28017 28024 28027 28051 28052 28053".split(" ")));
        public Zone copy() {
            Zone z = new Zone();
            z.good = new ArrayList<Area>();
            for (Area a : good) z.good.add(a.copy());
            z.postH = new ArrayList<String>(postH);
            z.postM = new ArrayList<String>(postM);
            z.postL = new ArrayList<String>(postL);
            return z;
        }
        /** Tipo de zona de un codigo postal (Z_HIGH, Z_MID o Z_LOW), o -1 si no esta en ninguna lista; si esta en varias manda la alta, luego la media y luego la baja. */
        public int postalKind(String cp) {
            if (cp == null) return -1;
            if (postH != null && postH.contains(cp)) return Z_HIGH;
            if (postM != null && postM.contains(cp)) return Z_MID;
            if (postL != null && postL.contains(cp)) return Z_LOW;
            return -1;
        }
    }

    /** Distancia en km entre dos puntos (formula de haversine). */
    public static double distKm(double lat1, double lon1, double lat2, double lon2) {
        double rad = Math.PI / 180.0, dLat = (lat2 - lat1) * rad, dLon = (lon2 - lon1) * rad;
        double a = Math.sin(dLat / 2) * Math.sin(dLat / 2) + Math.cos(lat1 * rad) * Math.cos(lat2 * rad) * Math.sin(dLon / 2) * Math.sin(dLon / 2);
        return 6371.0 * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    }

    /** La zona dibujada que contiene el punto (si cae en varias, manda la alta, luego la media y luego la baja), o null. */
    public static Area areaAt(Zone z, double lat, double lon) {
        if (z == null || z.good == null) return null;
        Area best = null;
        for (Area a : z.good) {
            if (a == null || !a.contains(lat, lon)) continue;
            if (best == null || a.kind > best.kind) best = a;
        }
        return best;
    }

    /** Nombre de la zona dibujada que contiene el punto, o null si no esta en ninguna. */
    public static String goodAreaAt(Zone z, double lat, double lon) {
        Area a = areaAt(z, lat, lon);
        return a == null ? null : a.name;
    }

    private static final Pattern POSTAL = Pattern.compile("(?<![\\d.,])(28\\d{3})(?!\\d|[.,]\\d)");

    /** Codigo postal (28xxx) de la direccion de RECOGIDA: el del texto mas cercano ANTES del bloque km/min del viaje con pasajero (en la tarjeta la recogida va antes que el destino). null si no hay o no se sabe cual es el viaje. */
    public static String pickupPostal(List<String> nodes, int tripFirst) {
        if (nodes == null || tripFirst <= 0) return null;
        for (int i = Math.min(tripFirst, nodes.size()) - 1; i >= 0; i--) {
            String s = nodes.get(i);
            if (s == null) continue;
            Matcher m = POSTAL.matcher(s);
            if (m.find()) return m.group(1);
        }
        return null;
    }

    public static class BoltCfg {
        public Zone zone = new Zone();
        // lo pone el servicio en cada lectura segun la ubicacion y la zona forzada (no se guarda)
        public int zoneKind = Z_MID;
        public String zoneName = "", zoneSrc = "default";
        public String zoneForce = "auto";    // auto (por tus zonas dibujadas) | low | mid | high
        public boolean zoneAsk = false;      // v3.65: "Preguntarme la zona cuando hay duda". Apagado de fabrica: el aviso no saca los botones baja / media / alta (vale la zona automatica)
        public int zoneDef = Z_MID;          // zona de la recogida cuando no cae en ninguna zona dibujada
        public boolean on = true;
        public String mode = "auto";         // auto (por las franjas) | week (siempre valle) | weekend (siempre punta)
        public double comm = 25;             // comision de Bolt, %
        public boolean peakApplies = true;   // la tarjeta de punta SUBE el precio estimado (apagado: se calcula con la de valle y se avisa de lo que saldria)
        public boolean round5 = true;        // el bruto se redondea a 5 centimos (como hace Bolt); el neto nunca se redondea
        public double fine = 0;              // ajuste fino (%) que se suma al calculo cuando hay demanda
        public double peakKm = 6.5;          // v3.34: la tarjeta de punta solo se usa en viajes de menos de estos km (0 = en todos)
        public double longKm = 10, longDisc = 13;   // v3.34: viajes largos (desde longKm km; desde la v3.56 con o sin demanda y tambien al aeropuerto): la tarjeta baja longDisc % (0 = sin descuento)
        public boolean distOn = true;        // v3.58: tabla "Ajuste por distancia" (solo Bolt normal, sin aeropuerto); apagada: el descuento fijo de viajes largos de siempre
        public double[] distCuts = distDefCuts();                          // "desde" (km) de cada tramo; el primero es 0
        public double[][] distN = distDefVals(), distD = distDefVals();    // % por zona (0 baja, 1 media, 2 alta) y tramo: sin demanda / con demanda
        public boolean eventOn = true;       // v3.34: en lugares de eventos (IFEMA, Bernabeu...) no se aplica ese descuento
        public boolean atEvent = false;      // lo pone el servicio en cada lectura segun la ubicacion (no se guarda)
        public boolean fixOk = false;        // v3.37: hay ubicacion reciente (la pone ZoneLocator; no se guarda)
        public double fixLat = 0, fixLon = 0, fixAcc = -1;   // v3.37: esa ubicacion y su precision en metros
        public String eventName = "";
        public double shortKm = 6, shortFrom = 1.2, bumpLo = 0, bumpHi = 0;   // viajes cortos con demanda: rango (menos de shortKm km y demanda desde shortFrom; el inicial real sube entre bumpLo y bumpHi euros)
        // zona baja / media / alta x valle / punta
        public Card lowV = new Card(2.02, 0.79, 0.13, 6.30), lowP = new Card(3.03, 0.80, 0.16, 8.85);
        public Card midV = new Card(2.10, 0.77, 0.15, 6.75), midP = new Card(2.68, 0.84, 0.20, 7.65);
        public Card highV = new Card(2.39, 0.85, 0.16, 6.70), highP = new Card(3.56, 0.91, 0.21, 8.35);
        // aeropuerto (solo las RECOGIDAS en el aeropuerto): valle / punta
        // v3.47: tarifa de aeropuerto del pasajero (Bolt). Las categorias tienen las suyas: airCatV / airCatP [0 comfort, 1 xl, 2 premium]
        public Card airV = new Card(3.04, 0.86, 0.15, 13.70), airP = new Card(3.04, 0.86, 0.15, 13.70);
        public Card[] airCatV = defaultAirCat(), airCatP = defaultAirCat();
        // v3.46: categorias de Bolt (Comfort, XL, Premium). catV / catP [categoria 0 comfort, 1 xl, 2 premium][zona 0 baja, 1 media, 2 alta]: valle / hora punta
        public String cat = "";              // categoria de la oferta que se esta leyendo ("", "comfort", "xl" o "premium"); la pone analyze() en cada lectura y no se guarda
        public Card[][] catV = defaultCat(false), catP = defaultCat(true);
        public boolean airOn = true;         // usar la tarjeta del aeropuerto en las recogidas
        public double airFee = 2.57;         // tasa del aeropuerto (recogidas y viajes hacia el aeropuerto): se resta del bruto ANTES de la comision
        public double airFlatKm = 11;        // recogida en el aeropuerto: hasta estos km solo vale la minima
        public List<Slot> slots = defaultSlots();         // hora punta de zona media
        public List<Slot> slotsL = defaultSlots();        // v3.51: hora punta de zona baja (lista propia)
        public List<Slot> slotsH = defaultSlotsHigh();    // hora punta de zona alta
        public boolean holidaysWe = true;    // los festivos cuentan como hora punta todo el dia
        public List<String> holidays = defaultHolidays();   // "yyyy-MM-dd" o "MM-dd"
    }

    // =====================================================================
    //  v3.46: categorias de Bolt. «Bolt» y «Electric» son el Bolt normal; Comfort, XL y Premium llevan sus propias tarjetas.
    //  De fabrica: tarjeta del Bolt normal de esa zona + la diferencia de su tarifa con la de Electric (valle, pantalla de tarifas del conductor).
    //  La hora punta (v3.47) lleva los precios reales de la pantalla de tarifas de Bolt.
    // =====================================================================
    // v3.48: la 4 es Child Seat / Booster Seat (valle con los precios reales de Bolt). En la zona media de valle el minuto es el de la pantalla de Bolt (Comfort 0,17, XL 0,25, Premium 0,21).
    private static final double[][][] CAT_V = {
        // v3.49: el Inicial de baja y media de Comfort, XL y Premium es el literal de la pantalla de tarifas de Bolt (km, minuto y minima ya lo eran); la alta no cambia
        { {6.49, 0.92, 0.15, 7.35}, {4.24, 0.90, 0.17, 7.90}, {2.80, 0.99, 0.18, 7.85} },
        { {4.52, 1.35, 0.22, 10.75}, {5.85, 1.32, 0.25, 11.55}, {4.09, 1.45, 0.27, 11.50} },
        { {8.05, 1.15, 0.18, 9.10}, {5.26, 1.12, 0.21, 9.80}, {3.47, 1.23, 0.23, 9.75} },
        { {3.80, 0.92, 0.15, 7.30}, {3.00, 0.89, 0.17, 7.85}, {2.77, 0.99, 0.18, 7.80} }
    };
    // v3.47: hora punta = precios reales de la pantalla de tarifas de Bolt (antes eran aproximados): [categoria][baja, media, alta] = {inicial, km, min, minima}
    private static final double[][][] CAT_P = {
        { {3.48, 0.94, 0.18, 10.35}, {3.54, 0.98, 0.23, 8.95}, {4.17, 1.06, 0.24, 9.80} },
        { {4.41, 1.37, 0.26, 15.10}, {4.54, 1.44, 0.33, 13.10}, {6.09, 1.56, 0.35, 14.30} },
        { {6.44, 1.16, 0.22, 12.80}, {3.95, 1.22, 0.28, 11.10}, {5.16, 1.32, 0.30, 12.10} },
        { {3.44, 0.93, 0.18, 10.25}, {3.50, 0.97, 0.23, 8.90}, {4.13, 1.06, 0.24, 9.70} }
    };

    /** Tarjetas de fabrica de las categorias: [0 comfort, 1 xl, 2 premium][0 baja, 1 media, 2 alta]. */
    public static Card[][] defaultCat(boolean peak) {
        double[][][] src = peak ? CAT_P : CAT_V;
        Card[][] r = new Card[4][3];   // v3.47: 4 categorias (la 4 = Child Seat / Booster Seat)
        for (int i = 0; i < 4; i++) for (int z = 0; z < 3; z++) r[i][z] = new Card(src[i][z][0], src[i][z][1], src[i][z][2], src[i][z][3]);
        return r;
    }

    // v3.47: tarjetas del aeropuerto (solo recogidas) de las categorias: [0 comfort, 1 xl, 2 premium] = {inicial, km, min, minima}. La hora punta de fabrica es igual que la de valle.
    private static final double[][] CAT_AIR = { {3.56, 1.01, 0.17, 16.00}, {5.20, 1.47, 0.25, 23.40}, {4.41, 1.25, 0.22, 19.85}, {3.56, 1.01, 0.17, 16.00} };   // la 4 (Child Seat) = Comfort

    public static Card[] defaultAirCat() {
        Card[] r = new Card[4];
        for (int i = 0; i < 4; i++) r[i] = new Card(CAT_AIR[i][0], CAT_AIR[i][1], CAT_AIR[i][2], CAT_AIR[i][3]);
        return r;
    }

    /** La tarjeta de una RECOGIDA en el aeropuerto: la de la categoria (Comfort, XL, Premium) si la hay; si no, la del aeropuerto de siempre. */
    public static Card airCard(BoltCfg c, boolean peak) {
        int i = catIndex(c.cat);
        Card base = peak ? c.airP : c.airV;
        if (i < 0) return base;
        Card[] a = peak ? c.airCatP : c.airCatV;
        return a == null || a[i] == null ? base : a[i];
    }

    public static int catIndex(String cat) { return "comfort".equals(cat) ? 0 : ("xl".equals(cat) ? 1 : ("premium".equals(cat) ? 2 : ("childseat".equals(cat) ? 3 : -1))); }   // v3.47: 3 = Child Seat / Booster Seat

    public static String catLabel(String cat) { return "comfort".equals(cat) ? "Comfort" : ("xl".equals(cat) ? "XL" : ("premium".equals(cat) ? "Premium" : ("childseat".equals(cat) ? "Child Seat" : ""))); }

    /** La tarjeta de la categoria (Comfort, XL o Premium) para la zona y el momento; sin categoria, la de la zona de siempre. */
    public static Card catCard(BoltCfg c, int kind, boolean peak) {
        int i = catIndex(c.cat);
        if (i < 0 || c.catV == null || c.catP == null) return zoneCard(c, kind, peak);
        int z = kind == Z_HIGH ? 2 : (kind == Z_LOW ? 0 : 1);
        Card k = (peak ? c.catP : c.catV)[i][z];
        return k == null ? zoneCard(c, kind, peak) : k;
    }

    /** Categoria de la oferta de Bolt por la palabra que sale arriba, donde pone «Bolt»: "comfort", "xl", "premium" o "" (Bolt normal, Electric o no se reconoce). */
    public static String detectCategory(List<String> nodes) {
        if (nodes == null) return "";
        for (String raw : nodes) {
            if (raw == null || raw.length() > 40) continue;
            String n = norm(raw).replaceAll("[^a-z0-9]+", " ").trim();
            if (n.length() == 0 || n.length() > 20) continue;
            if (n.matches("(bolt )?(comfort|confort)")) return "comfort";
            if (n.matches("(bolt )?xl")) return "xl";
            if (n.matches("(bolt )?premium")) return "premium";
            if (n.matches("(bolt )?(child|booster) ?seat")) return "childseat";   // v3.47: Child Seat y Booster Seat valen igual
            if (n.matches("(bolt )?(electric|electrico)")) return "";
        }
        return "";
    }

    /** La tarjeta de la zona dada, de punta o de valle. */
    public static Card zoneCard(BoltCfg c, int kind, boolean peak) {
        if (kind == Z_HIGH) return peak ? c.highP : c.highV;
        if (kind == Z_LOW) return peak ? c.lowP : c.lowV;
        return peak ? c.midP : c.midV;
    }

    /** Festivos nacionales fijos y el de la Comunidad de Madrid. Los que cambian cada ano (Semana Santa) se anaden a mano con aaaa-mm-dd. */
    public static List<String> defaultHolidays() {
        List<String> l = new ArrayList<String>();
        for (String s : new String[]{"01-01", "01-06", "05-01", "05-02", "08-15", "10-12", "11-01", "12-06", "12-08", "12-25"}) l.add(s);
        return l;
    }

    /** true si el dia del calendario es uno de los festivos de la lista. */
    public static boolean isHoliday(BoltCfg c, java.util.Calendar cal) {
        int mo = cal.get(java.util.Calendar.MONTH) + 1, dd = cal.get(java.util.Calendar.DAY_OF_MONTH), yy = cal.get(java.util.Calendar.YEAR);
        String full = String.format(Locale.ROOT, "%04d-%02d-%02d", yy, mo, dd), md = String.format(Locale.ROOT, "%02d-%02d", mo, dd);
        if (c.holidays != null) for (String h : c.holidays) if (full.equals(h) || md.equals(h)) return true;
        return false;
    }

    /** Minuto de la semana (0 = lunes 00:00 ... 10079 = domingo 23:59) de un instante. */
    public static int weekMinute(java.util.Calendar cal) {
        int dow = (cal.get(java.util.Calendar.DAY_OF_WEEK) + 5) % 7;       // lunes = 0 ... domingo = 6
        return dow * 1440 + cal.get(java.util.Calendar.HOUR_OF_DAY) * 60 + cal.get(java.util.Calendar.MINUTE);
    }

    /** true si ahora es hora punta en la zona actual (c.zoneKind): lo decide la franja en la que cae la hora (o un festivo), no el dia del calendario. */
    public static boolean isWeekend(BoltCfg c, java.util.Calendar cal) { return isPeak(c, c.zoneKind, cal); }

    /** true si en la zona dada es hora punta a ese instante. */
    public static boolean isPeak(BoltCfg c, int kind, java.util.Calendar cal) {
        if ("week".equals(c.mode)) return false;
        if ("weekend".equals(c.mode)) return true;
        if (c.holidaysWe && isHoliday(c, cal)) return true;
        int w = weekMinute(cal);
        List<Slot> l = kind == Z_HIGH ? c.slotsH : (kind == Z_LOW ? c.slotsL : c.slots);
        if (l != null) for (Slot s : l) if (s != null && s.on && s.contains(w)) return true;
        return false;
    }

    public static class Est {
        public double gross, comm, net, mult, fee;
        public double grossLo, grossHi, netLo, netHi;   // rango (solo si range)
        public boolean range;
        public double alt = -1;                          // neto con la tarjeta de punta si hay franja punta y no se aplica
        public String airport = "";          // "" | "pickup" | "dest"
        public boolean minApplied, weekend, peakUsed;    // weekend = franja de hora punta ahora
        public int zone = Z_MID;
        public double fine = 0;
        public double adj = 0;               // v3.58: ajuste por distancia aplicado (%, con signo)
        public double disc = 0;              // v3.34: descuento de viaje largo aplicado (%)
        public String event = "";            // v3.34: lugar de evento (se habria aplicado descuento y no se aplica)
        public boolean peakShort;            // v3.34: hora punta, pero el viaje es largo
    }

    // ---- aeropuerto: se detecta por el texto de la oferta ----
    // recogida: "parking P1 de la T1", "parking express T2", "parking modulo D planta 4 de la T4"
    private static final Pattern AIR_PICK_HINT = Pattern.compile("\\b(t\\s?[1-4]|p\\s?1|express|modulo\\s?d|terminal|aeropuerto|barajas)\\b");
    // destino: "Terminal 1..4", "Aeropuerto ..." (el barrio de Barajas o la Avenida de la Hispanidad NO cuentan)
    private static final Pattern AIR_DEST = Pattern.compile("terminal\\s?[1-4]|aeropuerto");

    /** "pickup" si se recoge en el aeropuerto, "dest" si el viaje va al aeropuerto, "" si no tiene que ver con el aeropuerto. */
    public static String detectAirport(List<String> nodes) {
        boolean pick = false, dest = false;
        if (nodes == null) return "";
        for (String raw : nodes) {
            if (raw == null || raw.length() > 120) continue;          // los textos largos (avisos, condiciones) no son direcciones
            String n = norm(raw);
            if (n.contains("parking") && AIR_PICK_HINT.matcher(n).find()) pick = true;
            else if (AIR_DEST.matcher(n).find()) dest = true;
        }
        return pick ? "pickup" : (dest ? "dest" : "");
    }

    // ---- v3.34: lugares de eventos (IFEMA, Bernabeu...): ahi no se aplica el descuento de los viajes largos con demanda (suposicion del conductor, se puede apagar en Ajustes) ----
    static final String[] EV_NAME = {"IFEMA", "Bernab\u00E9u", "Metropolitano", "Palacio Vistalegre", "WiZink Center"};
    // centro (latitud, longitud) y radio (metros): para la recogida, con la ubicacion del movil
    static final double[][] EV_GEO = {{40.46778, -3.61722, 1000}, {40.45305, -3.68834, 400}, {40.43614, -3.59947, 500}, {40.38611, -3.73889, 300}, {40.42390, -3.67170, 300}};
    // texto de la oferta (ya sin acentos y en minusculas): la recogida o el destino
    static final Pattern[] EV_TXT = {
        Pattern.compile("\\bifema\\b|feria de madrid|\\bpartenon\\b"),
        Pattern.compile("bernabeu"),
        Pattern.compile("estadio metropolitano|civitas|wanda metropolitano|riyadh air|luis aragones"),
        Pattern.compile("palacio (?:de )?vista(?:legre| alegre)"),
        Pattern.compile("wi ?zink|palacio de deportes")};

    /** Nombre del lugar de evento que sale en el texto de la oferta (recogida o destino), o "" si no sale ninguno. */
    public static String detectEvent(List<String> nodes) {
        if (nodes == null) return "";
        for (String raw : nodes) {
            if (raw == null || raw.length() > 120) continue;          // los textos largos (avisos, condiciones) no son direcciones
            String n = norm(raw);
            for (int i = 0; i < EV_TXT.length; i++) if (EV_TXT[i].matcher(n).find()) return EV_NAME[i];
        }
        return "";
    }

    /** Nombre del lugar de evento en el que esta la ubicacion dada (dentro de su radio), o "" si no esta en ninguno. */
    public static String eventAt(double lat, double lon) {
        double rad = Math.PI / 180.0;
        for (int i = 0; i < EV_GEO.length; i++) {
            double dLat = (lat - EV_GEO[i][0]) * rad, dLon = (lon - EV_GEO[i][1]) * rad;
            double a = Math.sin(dLat / 2) * Math.sin(dLat / 2) + Math.cos(EV_GEO[i][0] * rad) * Math.cos(lat * rad) * Math.sin(dLon / 2) * Math.sin(dLon / 2);
            double m = 6371000.0 * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
            if (m <= EV_GEO[i][2]) return EV_NAME[i];
        }
        return "";
    }

    /** Redondeo del bruto a 5 centimos (medio hacia arriba), sin ruido de coma flotante. */
    static double r5(BoltCfg c, double x) {
        if (!c.round5) return x;
        double v = Math.round(x * 1e6) / 1e6;
        return Math.floor(v * 20 + 0.5 + 1e-7) / 20.0;
    }

    public static Est estimate(BoltCfg c, boolean peak, double km, double min, double offerMult) { return estimate(c, peak, km, min, offerMult, ""); }

    /**
     * Bruto = (inicial + km*precioKm + min*precioMin, nunca menos que la minima) de la tarjeta que toca, x la demanda de la oferta (x1 si no hay), redondeado a 5 centimos.
     *  - Tarjeta: la de la ZONA de la recogida (c.zoneKind) y de valle o punta; solo las recogidas en el aeropuerto usan la del aeropuerto.
     *  - Punta: la tarjeta de punta solo cuenta si peak (franja) y c.peakApplies; si no, se calcula con valle y se guarda en alt lo que saldria con punta.
     *  - Aeropuerto (recogida o viaje hacia alli): se resta la tasa del bruto y despues se calcula la comision. Recogida: hasta airFlatKm solo vale la minima.
     *  - Viajes cortos con demanda: un solo neto (v3.44: ya no hay rango).
     */
    public static Est estimate(BoltCfg c, boolean peak, double km, double min, double offerMult, String airKind) {
        return estimate(c, peak, km, min, offerMult, airKind, c.atEvent && c.eventName != null ? c.eventName : "");
    }

    /**
     * v3.34: la tarjeta de punta solo cuenta en viajes de menos de c.peakKm km (0 = en todos). Los viajes largos (desde c.longKm km) CON demanda bajan la tarjeta c.longDisc %
     * (0 = sin descuento), salvo en un lugar de evento (event = su nombre, "" si no hay): ahi se cobra la tarifa normal.
     */
    public static Est estimate(BoltCfg c, boolean peak, double km, double min, double offerMult, String airKind, String event) {
        boolean air = c.airOn && ("pickup".equals(airKind) || "dest".equals(airKind));
        String ak = air ? airKind : "";
        String ev = event == null ? "" : event;
        boolean fits = c.peakKm <= 0 || km < c.peakKm;
        boolean up = peak && c.peakApplies && fits;
        Est e = calc(c, up, km, min, offerMult, ak, ev);
        e.weekend = peak; e.peakUsed = up; e.zone = c.zoneKind;
        e.peakShort = peak && c.peakApplies && !fits;
        if (peak && !c.peakApplies) e.alt = calc(c, true, km, min, offerMult, ak, ev).net;
        return e;
    }

    /** v3.58: tabla "Ajuste por distancia" de fabrica (PROVISIONAL: viajes del 5 al 16-11-2026; se afina con el mes entero). Igual que DIST_V0 y DISTD de la pagina. */
    static double[] distDefCuts() { return new double[]{0, 3, 6, 10, 15, 25}; }

    static double[][] distDefVals() {
        return new double[][]{{2, 2, -2, -7, -16, -18}, {2, 6, -2, -7, -16, -18}, {2, 2, -2, -7, -16, -18}};   // baja, media, alta
    }

    /** v3.58: % de la tabla "Ajuste por distancia" para esos km, esa zona de la recogida y con / sin demanda (igual que distPct de la pagina). */
    static double distPct(BoltCfg c, int zone, double km, boolean dem) {
        if (c.distCuts == null) return 0;
        int z = zone == Z_HIGH ? 2 : (zone == Z_LOW ? 0 : 1);
        double[][] t = dem ? c.distD : c.distN;
        if (t == null || t[z] == null) return 0;
        int idx = 0;
        for (int j = 0; j < c.distCuts.length; j++) if (km >= c.distCuts[j]) idx = j;
        return idx < t[z].length ? t[z][idx] : 0;
    }

    private static Est calc(BoltCfg c, boolean up, double km, double min, double offerMult, String ak, String ev) {
        boolean pickup = "pickup".equals(ak);
        boolean air = ak.length() > 0;
        Card card = pickup ? airCard(c, up) : catCard(c, c.zoneKind, up);   // v3.46: con categoria (Comfort, XL, Premium) su propia tarjeta (v3.47: tambien en el aeropuerto)
        double raw = card.base + km * card.perKm + min * card.perMin;
        boolean ma = false, flat = false;
        if (pickup && c.airFlatKm > 0 && km <= c.airFlatKm && card.minFare > 0) { raw = card.minFare; ma = true; flat = true; }   // v3.47: precio fijo = la minima y la tasa va APARTE (encima)
        else if (card.minFare > 0 && raw < card.minFare) { raw = card.minFare; ma = true; }
        double m = offerMult > 1.0 ? Math.min(10.0, offerMult) : 1.0;
        double fm = m > 1.0 + 1e-9 ? 1 + c.fine / 100.0 : 1.0;
        double disc = 0, adj = 0;
        String evShown = "";
        if (c.distOn && (!air || "dest".equals(ak)) && catIndex(c.cat) < 0) {   // v3.58: tabla "Ajuste por distancia" (Bolt normal): sustituye al descuento fijo de abajo; la minima tambien cuenta. v3.62: tambien en los viajes HACIA el aeropuerto (dest); la recogida en el aeropuerto (pickup) sigue con el descuento fijo
            double t = distPct(c, c.zoneKind, km, m > 1.0 + 1e-9);
            if (t < 0 && c.eventOn && ev.length() > 0) evShown = ev;
            else if (t != 0) { adj = t; if (t < 0) disc = -t; raw = raw * (1 + t / 100.0); }
        } else if (c.longDisc > 0 && !ma && km >= c.longKm) {   // v3.56: con o sin demanda, y tambien al aeropuerto
            if (c.eventOn && ev.length() > 0) evShown = ev;
            else { disc = c.longDisc; raw = raw * (1 - disc / 100.0); }
        }
        boolean range = false;   // v3.44: nunca hay rango (un solo neto); lo guardado en shortKm/shortFrom/bumpLo/bumpHi se ignora
        double mid = range ? raw + (c.bumpLo + c.bumpHi) / 2.0 : raw;
        double pct = Math.max(0, Math.min(90, c.comm));
        double fee = air ? c.airFee : 0;
        double gross = r5(c, mid * m * fm + (flat ? fee : 0));   // v3.47: con la minima fija el cliente paga la minima (con la demanda) + la tasa aparte; a la tasa no le afecta la demanda
        Est e = new Est();
        e.gross = gross; e.fee = fee;
        double after = fee > 0 ? Math.max(0, gross - fee) : gross;
        e.comm = after * pct / 100.0; e.net = after - e.comm;
        e.mult = m; e.fine = m > 1.0 + 1e-9 ? c.fine : 0; e.airport = ak; e.minApplied = ma; e.range = range; e.disc = disc; e.adj = adj; e.event = evShown;
        e.grossLo = e.gross; e.grossHi = e.gross; e.netLo = e.net; e.netHi = e.net;
        if (range) {
            e.grossLo = r5(c, (raw + c.bumpLo) * m * fm);
            e.grossHi = r5(c, (raw + c.bumpHi) * m * fm);
            double aLo = fee > 0 ? Math.max(0, e.grossLo - fee) : e.grossLo, aHi = fee > 0 ? Math.max(0, e.grossHi - fee) : e.grossHi;
            e.netLo = aLo * (1 - pct / 100.0); e.netHi = aHi * (1 - pct / 100.0);
        }
        return e;
    }


    // multiplicador de demanda que a veces muestra la oferta: "x1.7", "x1,4", "1.5x"
    private static final Pattern DEM1 = Pattern.compile("(?<![A-Za-z0-9])[x\u00d7]\\s?(\\d{1,2}(?:[.,]\\d{1,2})?)(?![\\d%A-Za-z])", Pattern.CASE_INSENSITIVE);
    private static final Pattern DEM2 = Pattern.compile("(?<![\\d.,])(\\d{1,2}(?:[.,]\\d{1,2})?)\\s?[x\u00d7](?![A-Za-z0-9])", Pattern.CASE_INSENSITIVE);

    static double detectDemand(List<String> nodes) {
        for (String t : nodes) {
            String s = t.trim(), n = norm(s);
            boolean dem = n.contains("demanda") || n.contains("surge") || n.contains("multiplicador");
            if (!dem && s.length() > 14) continue;
            Matcher m = DEM1.matcher(s);
            if (!m.find()) { m = DEM2.matcher(s); if (!m.find()) continue; }
            double v = num(m.group(1));
            if (v >= 1.0 && v <= 6.0) return v;
        }
        return -1;
    }

    /** Importe con 2 decimales y coma, sin ruido de coma flotante. */
    public static String money(double v) {
        return java.math.BigDecimal.valueOf(Math.round(v * 1e6) / 1e6).setScale(2, java.math.RoundingMode.HALF_UP).toPlainString().replace('.', ',');
    }

    /** Numero para la voz: coma decimal, sin ceros sobrantes (8,3 / 8 / 1,45). */
    private static String spokenNum(double v, int dec) {
        return java.math.BigDecimal.valueOf(v).setScale(dec, java.math.RoundingMode.HALF_UP).stripTrailingZeros().toPlainString().replace('.', ',');
    }


    /** Frase para el aviso por voz (con los valores reales de la oferta). null si no hay nada que decir. */
    public static String voiceText(Result r) {
        if (r == null || !r.isBolt || !r.offer) return null;
        if (r.estimated) {
            // v3.39: la voz dice primero el neto estimado (y el rango, si lo hay) y luego solo los km del viaje; corta, para que se oiga entera aunque rechaces enseguida
            String km = spokenNum(r.tripKm, 1);
            StringBuilder b = new StringBuilder("Neto estimado: ").append(money(r.estNet)).append(" euros");
            if (r.estRange && r.estNetLo >= 0 && r.estNetHi > r.estNetLo + 1e-9) b.append(", entre ").append(money(r.estNetLo)).append(" y ").append(money(r.estNetHi));
            b.append(". Viaje de ").append(km).append("1".equals(km) ? " kil\u00F3metro" : " kil\u00F3metros");
            b.append(".");
            return b.toString();
        }
        if (r.price > 0) return "Bolt. Precio de la oferta: " + money(r.price) + " euros.";
        return null;
    }


    private static class Item { int node; char kind; double v; boolean used; }
    private static class Seg { double km = -1, min = -1; String ctx = ""; int first = 99; }

    private static final Pattern EUR1 = Pattern.compile("(\\d{1,3}(?:\\.\\d{3})+,\\d{2}|\\d{1,4}[.,]\\d{1,2})\\s*(?:\u20AC|eur\\b)", Pattern.CASE_INSENSITIVE);
    private static final Pattern EUR2 = Pattern.compile("\u20AC\\s*(\\d{1,3}(?:\\.\\d{3})+,\\d{2}|\\d{1,4}[.,]\\d{1,2})", Pattern.CASE_INSENSITIVE);
    private static final Pattern KM = Pattern.compile("(\\d+(?:[.,]\\d+)?)\\s*km\\b", Pattern.CASE_INSENSITIVE);
    // «A 46 min del destino» / «A 12 km de tu destino»: distancia hasta TU destino (filtro de destino de Uber). No es un dato del viaje.
    private static final Pattern DEST_CHIP = Pattern.compile("^a\\s+\\d[\\d.,]*\\s*(?:min\\w*|km|kilometros?|h\\w*)\\b.*\\bdestino\\b");
    // v3.41: etiquetas de Uber con minutos que NO son un tramo: \u00ABViaje largo (m\u00E1s de 30 minutos)\u00BB. Solo se ignoran si la l\u00EDnea no trae km.
    private static final Pattern INFO_CHIP = Pattern.compile("^viaje largo\\b|^\\(?mas de \\d+\\s*(?:min|h)\\w*\\)?$");
    // v3.41 (solo lectura por imagen): unidades que el OCR confunde
    private static final Pattern OCR_KM = Pattern.compile("(?i)(\\d)\\s*(?:kn|krn|kin|kr|kmn|lkm|ikm|k\\s+m|km[.,;:])(?![a-z0-9])");
    private static final Pattern OCR_MIN = Pattern.compile("(?i)(\\d)\\s*(?:rnin|mln|m1n|m\\u00EDn|mim|rmin)(?![a-z0-9])");
    private static final Pattern OCR_TOK = Pattern.compile("(?i)(?<![A-Za-z0-9.,])([0-9OolI|]+(?:[.,][0-9OolI|]+)?)(\\s*(?:km|min)\\b)");
    private static final Pattern OCR_LONEKM = Pattern.compile("^[^\\d]{0,3}(\\d{1,3}[.,]\\d{1,2})\\s*([li]?k[mnrli]{0,2})[^A-Za-z0-9]*$", Pattern.CASE_INSENSITIVE);
    private static final Pattern OCR_MINKM = Pattern.compile("^(.*\\d\\s*min\\b[^A-Za-z0-9]{0,4})(\\d{1,3}[.,]\\d{1,2})\\s*([li]?k[mnrli]{0,2})[^A-Za-z0-9]*$", Pattern.CASE_INSENSITIVE);
    private static final Pattern MET = Pattern.compile("(?<![\\d.,])(\\d{2,4})\\s*m(?![a-zA-Z])");
    private static final Pattern MIN = Pattern.compile("(?:(\\d+)\\s*h(?:ora)?s?\\s*)?(\\d+)\\s*min", Pattern.CASE_INSENSITIVE);
    private static final Pattern HOURS = Pattern.compile("(?<![\\d.,])(\\d+)\\s*h(?:ora)?s?\\b(?!\\s*\\d+\\s*min)", Pattern.CASE_INSENSITIVE);
    private static final String[] PICK = {"recog", "recoj", "pasajero", "away", "de distancia", "cliente", "pickup", "hasta el"};
    private static final String[] TRIP = {"viaje", "trayecto", "recorrido", "destino", "trip", "total", "duracion", "drop"};
    private static final String[] ACCEPT = {"aceptar", "accept", "seleccionar", "rechazar", "reject", "declinar", "decline", "emparejar", "match", "asignar", "assign"};

    public static String norm(String s) {
        String n = Normalizer.normalize(s == null ? "" : s, Normalizer.Form.NFD).replaceAll("\\p{M}", "");
        return n.toLowerCase(Locale.ROOT);
    }

    private static double num(String s) {
        String t = s.trim();
        if (t.contains(",") && t.contains(".")) t = t.replace(".", "").replace(",", ".");
        else t = t.replace(",", ".");
        try { return Double.parseDouble(t); } catch (Exception e) { return -1; }
    }

    private static boolean has(String s, String[] kws) { for (String k : kws) if (s.contains(k)) return true; return false; }

    /** v3.41: arregla lo que el OCR suele leer mal en una linea de la oferta (solo se usa con lectura por imagen) */
    static String fixOcr(String s) {
        String x = s;
        x = x.replaceAll("(?i)(?<![A-Za-z0-9.,])[lI|](\\s*(?:min|rnin|mln|m1n|m\u00EDn|mim|rmin)(?![a-z0-9]))", "1$1");   // "l min" = "1 min" (tambien con la unidad mal leida)
        x = OCR_MIN.matcher(x).replaceAll("$1 min");
        x = OCR_KM.matcher(x).replaceAll("$1 km");
        // cifras con letras: l0 min -> 10 min, O,5 km -> 0,5 km (solo pegadas a km / min y con alguna cifra de verdad)
        Matcher m = OCR_TOK.matcher(x);
        StringBuffer sb = new StringBuffer();
        while (m.find()) {
            String tok = m.group(1);
            boolean real = false;
            for (int i = 0; i < tok.length(); i++) if (tok.charAt(i) >= '0' && tok.charAt(i) <= '9') real = true;
            String fixed = real ? tok.replace('O', '0').replace('o', '0').replace('l', '1').replace('I', '1').replace('|', '1') : tok;
            m.appendReplacement(sb, Matcher.quoteReplacement(fixed + m.group(2)));
        }
        m.appendTail(sb);
        x = sb.toString();
        // "5 min \u2022 2.4 kn": lo que sobra es un decimal + 1-3 letras raras = km
        Matcher a = OCR_MINKM.matcher(x);
        if (a.find() && !a.group(3).toLowerCase(Locale.ROOT).matches("min|mi|h")) return a.group(1) + a.group(2) + " km";
        Matcher b = OCR_LONEKM.matcher(x);
        if (b.find() && !b.group(2).toLowerCase(Locale.ROOT).matches("min|mi|h")) return b.group(1) + " km";
        return x;
    }

    private static String clean(String t) {
        String x = t == null ? "" : t.replace('\u00A0', ' ').replace('\u202F', ' ').replace('\u2009', ' ').replace('\u200A', ' ').replace('\u2007', ' ');
        x = x.replaceAll("(?i)\\bkil[o\u00F3]metros?\\b", "km").replaceAll("(?i)\\bminutos?\\b", "min").replaceAll("(?i)\\bmins\\b", "min");
        x = x.replaceAll("(?i)\\beuros?\\b", "\u20AC").replaceAll("(?i)(\\d)\\s*metros?\\b", "$1 m");
        return x;
    }

    /** el boton de aceptar de la oferta (no vale cualquier texto que contenga la palabra) */
    private static boolean isAcceptNode(String raw) {
        String n = norm(raw).replaceAll("[^a-z ]", " ").replaceAll("\\s+", " ").trim();
        if (n.length() == 0 || n.length() > 28) return false;
        return n.startsWith("aceptar") || n.startsWith("emparejar") || n.equals("accept") || n.equals("match") || isAssignNorm(n);   // v3.62: + «Asignar»
    }

    /** v3.62: el boton «Asignar» (o «Assign») de las ofertas que no cuentan como viaje salvo que las aceptes; la palabra entera al principio del texto del boton */
    private static boolean isAssignNorm(String n) {
        return n.equals("asignar") || n.startsWith("asignar ") || n.equals("assign") || n.startsWith("assign ");
    }
    private static boolean isAssignNode(String raw) {
        String n = norm(raw).replaceAll("[^a-z ]", " ").replaceAll("\\s+", " ").trim();
        if (n.length() == 0 || n.length() > 28) return false;
        return isAssignNorm(n);
    }

    // ---- peajes: un importe junto a la palabra \u00abpeaje\u00bb NO es el precio del viaje (se ignora al buscar el precio) ----
    private static final String AMT_RE = "(?:\\d{1,3}(?:\\.\\d{3})+,\\d{2}|\\d{1,4}(?:[.,]\\d{1,2})?)";
    private static final String TOLL_W = "(?<![\\p{L}])(?:peajes?|tolls?)(?![\\p{L}])";
    /** \u00abPeaje incluido 2,50 \u20ac\u00bb, \u00abPeajes: \u20ac2,50\u00bb, \u00abToll 2.50 EUR\u00bb (la palabra primero y el importe detras, con la moneda a un lado) */
    private static final Pattern TOLL_AFTER = Pattern.compile("(?i)" + TOLL_W + "[^\\d\u20AC]{0,25}?(?:\u20AC\\s*" + AMT_RE + "|" + AMT_RE + "\\s*(?:\u20AC|eur\\b))");
    /** \u00abIncluye 2,50 \u20ac de peajes\u00bb, \u00ab+2,50 \u20ac peaje\u00bb, \u00ab2,50 \u20ac de peaje\u00bb (importe con un nexo claro de peaje; \u00ab12,50 \u20ac Peaje incluido\u00bb NO se toca: ahi el importe es el precio) */
    private static final Pattern TOLL_BEFORE = Pattern.compile("(?i)(?:(?:incluy\\w*|incluid\\w*|incl\\.?|con|m[a\u00E1]s|\\+)\\s*" + AMT_RE + "\\s*(?:\u20AC|eur\\b)\\s*(?:(?:de|en|por)\\s+)?"
            + "|" + AMT_RE + "\\s*(?:\u20AC|eur\\b)\\s*(?:de|en|por)\\s+)" + TOLL_W);
    private static final Pattern TOLL_WORD = Pattern.compile("(?i)" + TOLL_W);
    private static final Pattern TOLL_LONE = Pattern.compile("^[+\\-]?\\s*(?:\u20AC\\s*)?" + AMT_RE + "\\s*(?:\u20AC|eur)?$", Pattern.CASE_INSENSITIVE);

    /**
     * Copia de los nodos SIN los importes de peaje, solo para buscar el precio. Los km, los minutos, el aviso del aeropuerto y todo lo demas
     * siguen leyendo los nodos originales. Si ninguno nombra el peaje, devuelve la misma lista (Uber y Cabify no cambian).
     */
    static List<String> withoutTolls(List<String> nodes) {
        boolean any = false;
        for (String s : nodes) if (TOLL_WORD.matcher(s).find()) { any = true; break; }
        if (!any) return nodes;
        List<String> out = new ArrayList<String>();
        boolean priceBefore = false;               // ya se vio un importe en euros antes (el precio suele ir arriba)
        for (int i = 0; i < nodes.size(); i++) {
            String s = nodes.get(i);
            if (TOLL_WORD.matcher(s).find()) {
                String c = TOLL_AFTER.matcher(s).replaceAll(" ");
                c = TOLL_BEFORE.matcher(c).replaceAll(" ");
                boolean hadAmount = !c.equals(s);
                boolean stillEur = EUR1.matcher(c).find() || EUR2.matcher(c).find();
                out.add(c.trim());
                // \u00abPeajes:\u00bb / \u00abPeaje incluido\u00bb en un nodo y el importe en el siguiente
                if (!hadAmount && !stillEur && i + 1 < nodes.size() && TOLL_LONE.matcher(nodes.get(i + 1).trim()).find()
                        && (s.trim().endsWith(":") || priceBefore)) { out.add(""); i++; }
                if (stillEur) priceBefore = true;
            } else {
                out.add(s);
                if (EUR1.matcher(s).find() || EUR2.matcher(s).find()) priceBefore = true;
            }
        }
        return out;
    }

    // v3.49: grupo 1 = lo que va delante, 2 = el importe, 3 = lo que va detras (el simbolo del euro, a veces mal leido)
    private static final Pattern LONEPRICE = Pattern.compile("^(\\D{0,3}?)(\\d{1,3}[.,]\\d{2})\\s*(\\S{0,2})$");
    /** v3.49 (solo lectura por imagen): precio SIN decimales: \u00AB13 \u20AC\u00BB, \u00AB13\u20AC\u00BB, \u00AB13 E\u00BB (el euro mal leido) */
    private static final Pattern INTPRICE = Pattern.compile("^[^\\d]{0,3}?(\\d{1,3})\\s*(?:\u20AC|eur\\b|[EC\u00A3])[^A-Za-z0-9]{0,2}$|^\u20AC\\s*(\\d{1,3})[^A-Za-z0-9]{0,2}$", Pattern.CASE_INSENSITIVE);
    /** v3.49: la nota del pasajero lleva estrella (\u2605 4,60): nunca es el precio */
    private static final Pattern STAR = Pattern.compile("[\u2605\u2606\u2B50\u272D\u2729\u272A*]");

    private static int stMin(double v, double min, double tolPct) {
        if (v >= min) return 0;
        return v >= min * (1 - tolPct / 100.0) ? 1 : 2;
    }

    public static Result analyze(List<String> rawNodes, Params p) { return analyze(rawNodes, p, false); }

    public static Result analyze(List<String> rawNodes, Params p, boolean lenient) { return analyze(rawNodes, p, lenient, false); }

    /** isBolt: la oferta viene de Bolt (paquete bolt/mtakso). Solo en ese caso, y sin precio visible, se estima el precio. */
    public static Result analyze(List<String> rawNodes, Params p, boolean lenient, boolean isBolt) {
        // v3.46: la categoria de la oferta (Comfort, XL, Premium) solo vale durante esta lectura
        String cat0 = p != null && p.bolt != null ? p.bolt.cat : null;
        if (isBolt && p != null && p.bolt != null) p.bolt.cat = detectCategory(rawNodes);
        try {
            Result r = analyzeCore(rawNodes, p, lenient, isBolt);
            try { addZoneChoices(r, rawNodes, p, lenient, isBolt); }
            catch (Throwable t) { r.zoneAuto = -1; r.zoneKinds = new int[0]; r.zoneNets = new double[0]; }
            return r;
        } finally {
            if (p != null && p.bolt != null) p.bolt.cat = cat0 == null ? "" : cat0;
        }
    }

    /** v3.37: la zona de la recogida solo se ofrece a elegir si cambia el neto al menos esto (euros) */
    public static final double ZONE_MIN_DIFF = 0.25;

    /** v3.37: la recogida esta como mucho a (km de la oferta x este numero) en linea recta de ti (los km de la oferta son por carretera) */
    public static final double ZONE_STRAIGHT = 0.8;

    /** v3.37: huella de la oferta SIN la zona (viaje y recogida): la zona elegida a mano en el aviso solo vale para la oferta con esta huella */
    public static String baseSig(Result r) {
        return Math.round(r.tripKm * 10) + "|" + Math.round(r.tripMin) + "|" + Math.round(r.pickupKm * 10) + "|" + Math.round(r.pickupMin) + "|e";
    }

    /** v3.37: zonas (0 baja, 1 media, 2 alta) que hay en los alrededores de la ubicacion hasta donde puede estar la recogida; marca true en reach */
    public static void reachKinds(BoltCfg b, double pickupKm, boolean[] reach) {
        double acc = b.fixAcc > 0 ? Math.min(b.fixAcc, 300) : 0;
        double rM = (pickupKm > 0 ? pickupKm * 1000.0 * ZONE_STRAIGHT : 300.0) + acc;
        rM = Math.min(rM, 4000.0);
        double step = Math.max(120.0, rM / 12.0);
        int n = (int) Math.ceil(rM / step);
        double mLat = 1.0 / 111320.0, mLon = 1.0 / (111320.0 * Math.max(0.2, Math.cos(Math.toRadians(b.fixLat))));
        for (int i = -n; i <= n; i++) {
            for (int j = -n; j <= n; j++) {
                double dx = i * step, dy = j * step;
                if (dx * dx + dy * dy > rM * rM) continue;
                Area a = areaAt(b.zone, b.fixLat + dy * mLat, b.fixLon + dx * mLon);
                int k = a != null ? a.kind : b.zoneDef;
                if (k >= Z_LOW && k <= Z_HIGH) reach[k] = true;
            }
        }
    }

    /** v3.37: neto de la oferta con la zona "kind" (la de la ubicacion si kind == auto); -1 si no se puede */
    private static double netWith(List<String> rawNodes, Params p, boolean lenient, boolean isBolt, int kind, int auto, String sig) {
        int k0 = p.manualKind; String s0 = p.manualSig; boolean n0 = p.noStreets;
        try {
            p.manualKind = kind == auto ? -1 : kind;
            p.manualSig = sig;
            p.noStreets = kind == auto;      // v3.57: la zona «de la ubicacion» no mira las calles guardadas
            Result q = analyzeCore(rawNodes, p, lenient, isBolt);
            if (!q.estimated || q.estNet < 0) return -1;
            if (kind != auto && !"manual".equals(q.estZoneSrc)) return -1;
            return q.estNet;
        } finally { p.manualKind = k0; p.manualSig = s0; p.noStreets = n0; }
    }

    /**
     * v3.37: si la zona de la recogida salio de la UBICACION (no del codigo postal ni de Ajustes) y cerca hay otra zona (o el codigo postal de la oferta no esta en tus listas),
     * deja en el resultado las zonas entre las que elegir y el neto de cada una. Solo se ofrecen las que cambian el neto al menos ZONE_MIN_DIFF euros.
     */
    private static void addZoneChoices(Result r, List<String> rawNodes, Params p, boolean lenient, boolean isBolt) {
        if (r == null || !r.offer || !r.estimated || p == null || p.bolt == null) return;
        BoltCfg b = p.bolt;
        r.baseSig = baseSig(r);
        r.estNetAuto = r.estNet;
        String src = r.estZoneSrc == null ? "" : r.estZoneSrc;
        boolean manual = "manual".equals(src) || "street".equals(src);   // v3.57: la calle guardada se trata como una eleccion tuya (se puede cambiar con los botones)
        int auto = b.zoneKind;
        if (auto < Z_LOW || auto > Z_HIGH) return;
        if (manual) { double na = netWith(rawNodes, p, lenient, isBolt, auto, auto, r.baseSig); if (na >= 0) r.estNetAuto = na; }
        if (!(manual || "area".equals(src) || "default".equals(src))) return;       // codigo postal o zona forzada: no hay duda que resolver
        if (!b.zoneAsk) return;                                                       // v3.65: "Preguntarme la zona cuando hay duda" apagado: sin botones de zona
        if ("pickup".equals(r.estAirport)) return;                                   // recogida en el aeropuerto: usa su propia tarjeta, la zona no cuenta
        boolean[] reach = new boolean[3];
        reach[auto] = true;
        if (r.estCpUnlisted != null && r.estCpUnlisted.length() > 0) { reach[0] = true; reach[1] = true; reach[2] = true; }
        else if (b.fixOk) reachKinds(b, r.pickupKm, reach);
        else return;
        if (manual && r.estZone >= Z_LOW && r.estZone <= Z_HIGH) reach[r.estZone] = true;
        if (r.estCpKind >= Z_LOW && r.estCpKind <= Z_HIGH) reach[r.estCpKind] = true;      // v3.49: la zona que dice el codigo postal tambien se puede elegir
        int cnt = 0;
        for (int k = 0; k < 3; k++) if (reach[k]) cnt++;
        if (cnt < 2) return;
        double base = manual ? r.estNetAuto : r.estNet;
        double[] net = new double[3];
        for (int k = 0; k < 3; k++) {
            if (!reach[k]) { net[k] = -1; continue; }
            if (k == r.estZone) net[k] = r.estNet;
            else if (k == auto && manual) net[k] = r.estNetAuto;
            else net[k] = netWith(rawNodes, p, lenient, isBolt, k, auto, r.baseSig);
        }
        int[] ks = new int[3]; int m = 0;
        for (int k = 0; k < 3; k++) {
            if (!reach[k] || net[k] < 0) continue;
            if (k == auto || k == r.estZone || Math.abs(net[k] - base) >= ZONE_MIN_DIFF - 1e-9) ks[m++] = k;
        }
        if (m < 2) return;
        r.zoneAuto = auto;
        r.zoneKinds = new int[m]; r.zoneNets = new double[m];
        for (int i = 0; i < m; i++) { r.zoneKinds[i] = ks[i]; r.zoneNets[i] = net[ks[i]]; }
    }

    private static Result analyzeCore(List<String> rawNodes, Params p, boolean lenient, boolean isBolt) {
        List<String> nodes = new ArrayList<String>();
        for (String x : rawNodes) for (String line0 : clean(x).split("\\n")) {
            String line = lenient ? fixOcr(line0) : line0;
            if (line.trim().length() == 0 || DEST_CHIP.matcher(norm(line).trim()).find()) continue;
            if (INFO_CHIP.matcher(norm(line).trim()).find() && !KM.matcher(line).find()) continue;     // v3.41: "Viaje largo (m\u00E1s de 30 min)"
            nodes.add(line.trim());
        }
        Result r = new Result();
        // ---- precio: primer importe en euros razonable (sin contar los importes de peaje)
        List<String> priceNodes = withoutTolls(nodes);
        for (String t : priceNodes) {
            Matcher m = EUR1.matcher(t); double v = -1;
            if (m.find()) v = num(m.group(1)); else { Matcher m2 = EUR2.matcher(t); if (m2.find()) v = num(m2.group(1)); }
            if (v >= 1.0 && v < 1000) { r.price = v; break; }
        }
        if (r.price <= 0 && lenient) {
            // v3.49: precio entero (\u00AB13 \u20AC\u00BB) y sin confundirlo con la nota del pasajero (\u00AB\u2605 4,60\u00BB). Se prefiere el importe con simbolo de euro (aunque venga mal leido);
            // el importe suelto solo vale por encima de los tramos (km / min) o si pasa de 5,00 (una nota no pasa de 5)
            int firstSeg = priceNodes.size();
            for (int i = 0; i < priceNodes.size(); i++) { String t = priceNodes.get(i); if (KM.matcher(t).find() || MIN.matcher(t).find()) { firstSeg = i; break; } }
            double bestV = -1; int bestRank = 99; boolean bestInt = false;
            for (int i = 0; i < priceNodes.size(); i++) {
                String t = priceNodes.get(i).trim();
                if (STAR.matcher(t).find()) continue;
                if (i > 0 && priceNodes.get(i - 1).trim().length() <= 2 && STAR.matcher(priceNodes.get(i - 1)).find()) continue;   // la estrella va en la linea de encima
                double v = -1; int rank = 99; boolean isInt = false;
                Matcher mi = INTPRICE.matcher(t);
                Matcher ml = LONEPRICE.matcher(t);
                if (mi.find()) { v = num(mi.group(1) != null ? mi.group(1) : mi.group(2)); rank = 1; isInt = true; }
                else if (ml.find()) {
                    v = num(ml.group(2));
                    String suf = ml.group(3);
                    boolean euroish = suf.length() > 0 && !suf.matches(".*[\u2022\u00B7.,:;|\\-].*");
                    rank = euroish ? 1 : (i < firstSeg ? 2 : (v > 5.0 ? 3 : 99));
                }
                if (!(v >= 1.0 && v < 1000) || rank == 99) continue;
                // mismo grado: gana el primero, pero un importe de mas de 5,00 le gana a uno de 5,00 o menos (puede ser una nota)
                if (rank < bestRank || (rank == bestRank && bestV <= 5.0 && v > 5.0)) { bestV = v; bestRank = rank; bestInt = isInt; }
            }
            if (bestV > 0) { r.price = bestV; if (bestInt) r.ocrFix = "precio entero"; }
        }
        // ---- elementos km / min por nodo
        List<Item> items = new ArrayList<Item>();
        StringBuilder all = new StringBuilder();
        for (int i = 0; i < nodes.size(); i++) {
            String t = nodes.get(i); all.append(norm(t)).append('\n');
            Matcher k = KM.matcher(t);
            while (k.find()) { Item it = new Item(); it.node = i; it.kind = 'k'; it.v = num(k.group(1)); items.add(it); }
            String rest = KM.matcher(t).replaceAll(" ");
            Matcher mt = MET.matcher(rest);
            while (mt.find()) { Item it = new Item(); it.node = i; it.kind = 'k'; it.v = num(mt.group(1)) / 1000.0; items.add(it); }
            Matcher mi = MIN.matcher(t);
            while (mi.find()) { Item it = new Item(); it.node = i; it.kind = 'm'; it.v = (mi.group(1) != null ? num(mi.group(1)) * 60 : 0) + num(mi.group(2)); items.add(it); }
        }
        boolean accept = false;
        boolean assign = false;
        for (String nd : nodes) if (isAcceptNode(nd)) { accept = true; assign = isAssignNode(nd); break; }
        r.acceptSeen = accept;
        r.assignOffer = assign;   // v3.62
        int kmCount = 0, minCount = 0;
        for (Item it : items) { if (it.kind == 'k') kmCount++; else minCount++; }
        r.offer = accept && kmCount >= 1 && minCount >= 1 && (r.price > 0 || (kmCount >= 2 && minCount >= 2));
        if (!r.offer) { r.why = "precio=" + r.price + " km=" + kmCount + " min=" + minCount + " aceptar=" + accept; return r; }
        // ---- emparejar km con minutos: 1) mismo nodo, 2) nodos contiguos
        List<Seg> segs = new ArrayList<Seg>();
        List<Item[]> pairs = new ArrayList<Item[]>();
        // fase A: km y minutos en el mismo nodo
        for (Item a : items) {
            if (a.kind != 'k' || a.used) continue;
            for (Item b : items) {
                if (b.kind == 'm' && !b.used && b.node == a.node) { a.used = true; b.used = true; pairs.add(new Item[]{a, b}); break; }
            }
        }
        // v3.41 (solo lectura por imagen): en Uber el minuto va SIEMPRE antes del km; si hay una direcci\u00F3n en medio, se busca hacia atr\u00E1s (hasta 3 nodos) antes de mirar el nodo siguiente
        if (lenient) {
            for (Item a : items) {
                if (a.kind != 'k' || a.used) continue;
                Item best = null;
                for (int d = 1; d <= 3 && best == null; d++) for (Item b : items) if (b.kind == 'm' && !b.used && b.node == a.node - d) { best = b; break; }
                if (best != null) { a.used = true; best.used = true; pairs.add(new Item[]{a, best}); }
            }
        }
        // fase B: el minuto va justo antes del km (tambien con un "\u2022" entre medias) o, si no, justo despues
        for (Item a : items) {
            if (a.kind != 'k' || a.used) continue;
            Item best = null;
            for (int d = 1; d <= 2 && best == null; d++) {
                if (d == 2 && (a.node < 1 || nodes.get(a.node - 1).trim().length() > 2)) break;
                for (Item b : items) if (b.kind == 'm' && !b.used && b.node == a.node - d) { best = b; break; }
            }
            if (best == null) for (Item b : items) if (b.kind == 'm' && !b.used && b.node == a.node + 1) { best = b; break; }
            if (best != null) { a.used = true; best.used = true; pairs.add(new Item[]{a, best}); }
        }
        for (Item a : items) if (a.kind == 'k' && !a.used) { a.used = true; pairs.add(new Item[]{a, null}); }
        for (Item[] pr : pairs) {
            Seg s = new Seg(); s.km = pr[0].v; s.first = pr[0].node;
            StringBuilder own = new StringBuilder(norm(nodes.get(pr[0].node)));
            int firstNode = pr[0].node;
            if (pr[1] != null) { s.min = pr[1].v; firstNode = Math.min(firstNode, pr[1].node); s.first = firstNode; if (pr[1].node != pr[0].node) own.append(' ').append(norm(nodes.get(pr[1].node))); }
            String ownS = own.toString();
            // si el propio texto no trae pistas, se mira la l\u00EDnea anterior (etiqueta encima del valor)
            String prevS = firstNode > 0 ? norm(nodes.get(firstNode - 1)).trim() : "";
            boolean prevIsLabel = prevS.length() > 0 && prevS.length() <= 22 && !prevS.matches(".*\\d.*");
            s.ctx = (has(ownS, PICK) || has(ownS, TRIP) || !prevIsLabel) ? ownS : ownS + " " + prevS;
            segs.add(s);
        }
        for (Item b : items) {
            if (b.kind == 'm' && !b.used) { Seg s = new Seg(); s.min = b.v; s.first = b.node; s.ctx = norm(nodes.get(b.node)) + (b.node > 0 ? " " + norm(nodes.get(b.node - 1)) : ""); segs.add(s); }
        }
        java.util.Collections.sort(segs, new java.util.Comparator<Seg>() { public int compare(Seg x, Seg y) { return x.first - y.first; } });
        // v3.49 (solo lectura por imagen): el OCR pierde a veces la coma de los km ("1.8" -> "18", "4.6" -> "46") y lee "0 km" en la recogida.
        // Una velocidad de mas de 130 km/h no existe en la ciudad: si dividiendo los km entre 10 sale una velocidad normal, era la coma. "0 km" con 3 min o menos es una recogida de verdad.
        if (lenient) {
            for (Seg s : segs) {
                if (s.min > 0 && s.km > 0) {
                    double sp = s.km / (s.min / 60.0);
                    if (sp > 130 && sp / 10.0 >= 4) { s.km = s.km / 10.0; r.ocrFix += (r.ocrFix.length() > 0 ? " + " : "") + "coma de los km"; }
                } else if (s.km == 0 && s.min > 0 && s.min <= 3) {
                    s.km = 0.01; r.ocrFix += (r.ocrFix.length() > 0 ? " + " : "") + "0 km";
                }
            }
        }
        // v3.41: si ya hay dos tramos completos (km y minutos), los trozos sueltos que sobran no cuentan como recogida ni como viaje
        int completeSegs = 0;
        for (Seg s : segs) if (s.km > 0 && s.min > 0) completeSegs++;
        if (lenient && completeSegs >= 2) {
            for (java.util.Iterator<Seg> itS = segs.iterator(); itS.hasNext(); ) { Seg s = itS.next(); if (!(s.km > 0 && s.min > 0)) itS.remove(); }
        }
        // ---- recogida o viaje
        Seg pick = null, trip = null;
        for (Seg s : segs) {
            boolean ip = has(s.ctx, PICK), it = has(s.ctx, TRIP);
            if (ip && !it && pick == null) pick = s; else if (it && !ip && trip == null) trip = s;
        }
        List<Seg> rest = new ArrayList<Seg>();
        for (Seg s : segs) if (s != pick && s != trip) rest.add(s);
        if (pick == null && trip == null && rest.size() >= 2) { pick = rest.get(0); trip = rest.get(1); r.orderAssumed = true; }
        else if (trip == null && !rest.isEmpty()) { trip = rest.get(rest.size() - 1); if (pick == null && rest.size() >= 2) pick = rest.get(0); r.orderAssumed = true; }
        else if (pick == null && !rest.isEmpty() && trip != null) { pick = rest.get(0); r.orderAssumed = true; }
        if (trip != null) { r.tripKm = trip.km; r.tripMin = trip.min; }
        if (pick != null) { r.pickupKm = pick.km; r.pickupMin = pick.min; }
        // ---- Bolt sin precio visible: estimacion con los km y minutos del viaje con pasajero (nunca los de recogida)
        r.isBolt = isBolt;
        boolean useEstimate = false;
        boolean boltEst = isBolt && p.bolt != null && p.bolt.on;
        if (r.price <= 0 && boltEst) {
            boolean tripSure = !(r.orderAssumed && pick == null);   // un unico bloque sin etiqueta no se da por viaje
            if (tripSure && r.tripKm > 0 && r.tripMin > 0) {
                double om = detectDemand(nodes);
                // v3.20-cp: si la tarjeta trae el codigo postal de la RECOGIDA y esta en las listas de Ajustes, manda sobre el GPS (salvo zona forzada)
                int zk0 = p.bolt.zoneKind; String zn0 = p.bolt.zoneName, zs0 = p.bolt.zoneSrc; boolean peakZ = p.weekendNow;
                try {
                    if (p.bolt.zoneForce == null || "auto".equals(p.bolt.zoneForce)) {
                        String cpZ = trip == null ? null : pickupPostal(nodes, trip.first);
                        int kz = cpZ == null || p.bolt.zone == null ? -1 : p.bolt.zone.postalKind(cpZ);
                        boolean cpListed = kz >= 0;
                        // v3.49: si tienes zonas pintadas y el movil da la ubicacion, manda tu mapa ENTERO (tus zonas y, fuera de ellas, la zona por defecto); el codigo postal solo vale sin zonas pintadas o sin ubicacion
                        boolean mapRules = "area".equals(zs0) || (p.bolt.fixOk && p.bolt.zone != null && p.bolt.zone.good != null && !p.bolt.zone.good.isEmpty());
                        if (mapRules) { if (cpListed) r.estCpKind = kz; kz = -1; }   // y se apunta la zona del codigo para ofrecerla como boton
                        if (kz >= 0) {
                            p.bolt.zoneKind = kz; p.bolt.zoneName = "c\u00F3digo postal " + cpZ; p.bolt.zoneSrc = "postal";
                            if (kz != zk0) { java.util.Calendar calZ = java.util.Calendar.getInstance(); if (p.nowMs > 0) calZ.setTimeInMillis(p.nowMs); peakZ = isPeak(p.bolt, kz, calZ); }
                        } else if (cpZ != null && !cpListed) {
                            r.estCpUnlisted = cpZ;      // v3.37: la oferta trae codigo postal pero no esta en tus listas: se usa la ubicacion y se avisa
                        }
                        // v3.57: direccion de la recogida y, si esta en tus calles guardadas, su zona (manda sobre el codigo postal y el mapa; no sobre lo que acabas de elegir en este aviso)
                        StreetMemory.Addr adr = trip == null ? null : StreetMemory.pickupAddress(nodes, trip.first);
                        int mk = -1; StreetMemory.Entry me = null;
                        if (adr != null) {
                            r.pickStreet = adr.street; r.pickNum = adr.num; r.pickCp = adr.cp;
                            if (p.streets != null && !p.noStreets) { me = StreetMemory.find(p.streets, adr); if (me != null && me.num.length() > 0) mk = me.zone; }   // un tramo dudoso (sin numero) no se aplica solo: hasta que le pongas el numero sigues eligiendo en el aviso
                        }
                        // v3.37: zona elegida a mano en el aviso: solo vale para ESTA oferta y solo si la zona salia de la ubicacion (no de un codigo postal de tus listas ni de Ajustes) o de una calle guardada
                        if ((kz < 0 || mk >= 0) && p.manualKind >= Z_LOW && p.manualKind <= Z_HIGH && p.manualSig != null && p.manualSig.length() > 0 && p.manualSig.equals(baseSig(r))) {
                            p.bolt.zoneKind = p.manualKind; p.bolt.zoneName = ""; p.bolt.zoneSrc = "manual";
                            java.util.Calendar calM = java.util.Calendar.getInstance(); if (p.nowMs > 0) calM.setTimeInMillis(p.nowMs);
                            peakZ = isPeak(p.bolt, p.manualKind, calM);
                        } else if (mk >= Z_LOW && mk <= Z_HIGH) {
                            p.bolt.zoneKind = mk; p.bolt.zoneName = me.street + (me.num.length() > 0 ? " " + me.num : ""); p.bolt.zoneSrc = "street"; r.memKey = me.key();
                            java.util.Calendar calS = java.util.Calendar.getInstance(); if (p.nowMs > 0) calS.setTimeInMillis(p.nowMs);
                            peakZ = isPeak(p.bolt, mk, calS);
                        }
                    }
                } catch (Exception ex) { p.bolt.zoneKind = zk0; p.bolt.zoneName = zn0; p.bolt.zoneSrc = zs0; peakZ = p.weekendNow; }
                String evN = "";
                if (p.bolt.eventOn) { if (p.bolt.atEvent && p.bolt.eventName != null) evN = p.bolt.eventName; if (evN.length() == 0) evN = detectEvent(nodes); }
                Est e = estimate(p.bolt, peakZ, r.tripKm, r.tripMin, om, detectAirport(nodes), evN);
                r.estimated = true; r.estGross = e.gross; r.estComm = e.comm; r.estNet = e.net; r.estMult = e.mult;
                r.estOfferMult = om;
                r.estCat = p.bolt.cat == null ? "" : p.bolt.cat;
                r.estAirport = e.airport; r.estFee = e.fee;
                r.estZone = e.zone; r.estArea = p.bolt.zoneName; r.estZoneSrc = p.bolt.zoneSrc;
                p.bolt.zoneKind = zk0; p.bolt.zoneName = zn0; p.bolt.zoneSrc = zs0;
                r.estRange = e.range; r.estNetLo = e.range ? e.netLo : -1; r.estNetHi = e.range ? e.netHi : -1;
                r.estAlt = e.alt; r.estPeakUsed = e.peakUsed; r.estFine = e.fine; r.estDisc = e.disc; r.estAdj = e.adj; r.estEvent = e.event; r.estPeakShort = e.peakShort;
                r.estMinApplied = e.minApplied; r.estWeekend = e.weekend; r.estCommPct = Math.max(0, Math.min(90, p.bolt.comm));
                r.price = e.net;          // el semaforo se juzga sobre el NETO estimado; no se vuelve a descontar comision
                useEstimate = true;
            }
        }
        // ---- oferta sin precio visible: solo se puede juzgar la distancia de recogida
        if (r.price <= 0) {
            r.stP = r.pickupKm > 0 ? (r.pickupKm <= p.maxPickup ? 0 : (r.pickupKm <= p.maxPickup + p.tolPickup ? 1 : 2)) : -1;
            if (r.stP == 2) { r.verdict = "NO"; r.reason = String.format(Locale.GERMANY, "recogida %.1f km (m\u00E1x. %.1f)", r.pickupKm, p.maxPickup); }
            else { r.verdict = "DATA"; r.reason = boltEst ? "No se pudo estimar el precio de Bolt: faltan los km o los minutos del viaje con pasajero." : "Esta oferta no muestra el precio."; }
            return r;
        }
        // ---- datos suficientes
        if (r.tripKm <= 0 || r.tripMin <= 0) { r.verdict = "DATA"; r.reason = r.tripMin <= 0 ? "No se pudo leer el tiempo del viaje." : "No se pudo leer la distancia del viaje."; return r; }
        double net = useEstimate ? r.price : r.price * (1 - Math.max(0, Math.min(90, p.commission)) / 100.0);
        double km = r.tripKm + (p.includePickup && r.pickupKm > 0 ? r.pickupKm : 0);
        double min = r.tripMin + (p.includePickup && r.pickupMin > 0 ? r.pickupMin : 0);
        r.perKm = net / km; r.perHour = net / (min / 60.0);
        List<String> bad = new ArrayList<String>();
        r.stH = stMin(r.perHour, p.minHour, p.tolPct);
        r.stK = stMin(r.perKm, p.minKm, p.tolPct);
        r.stP = r.pickupKm > 0 ? (r.pickupKm <= p.maxPickup ? 0 : (r.pickupKm <= p.maxPickup + p.tolPickup ? 1 : 2)) : -1;
        if (r.stH > 0) bad.add(String.format(Locale.GERMANY, "\u20AC/h %.1f (m\u00EDn. %.2f)", r.perHour, p.minHour));
        if (r.stK > 0) bad.add(String.format(Locale.GERMANY, "\u20AC/km %.2f (m\u00EDn. %.2f)", r.perKm, p.minKm));
        if (r.stP > 0) bad.add(String.format(Locale.GERMANY, "recogida %.1f km (m\u00E1x. %.1f)", r.pickupKm, p.maxPickup));
        int worst = Math.max(r.stH, Math.max(r.stK, r.stP));
        r.verdict = worst >= 2 ? "NO" : (worst == 1 ? "WARN" : "OK");
        r.reason = bad.isEmpty() ? "Cumple tus objetivos." : join(bad);
        return r;
    }

    private static String join(List<String> l) { StringBuilder b = new StringBuilder(); for (int i = 0; i < l.size(); i++) { if (i > 0) b.append(" \u00B7 "); b.append(l.get(i)); } return b.toString(); }
}
