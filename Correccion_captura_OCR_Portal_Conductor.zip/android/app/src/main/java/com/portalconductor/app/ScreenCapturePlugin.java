package com.portalconductor.app;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.Base64;
import android.util.DisplayMetrics;
import android.view.WindowManager;

import com.getcapacitor.ActivityCallback;
import com.getcapacitor.ActivityResult;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.JSObject;

import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;

@CapacitorPlugin(name = "ScreenCapture")
public class ScreenCapturePlugin extends Plugin {
    private MediaProjection projection;
    private VirtualDisplay display;
    private ImageReader reader;
    private PluginCall pendingCall;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private BroadcastReceiver serviceReadyReceiver;
    private boolean receiverRegistered = false;

    @PluginMethod
    public void captureScreen(PluginCall call) {
        if (pendingCall != null) {
            call.reject("Ya hay una captura en curso.");
            return;
        }
        MediaProjectionManager manager = (MediaProjectionManager)
                getContext().getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        if (manager == null) {
            call.reject("Android no permite iniciar la captura de pantalla.");
            return;
        }
        pendingCall = call;
        startActivityForResult(call, manager.createScreenCaptureIntent(), "onProjectionPermission");
    }

    @ActivityCallback
    private void onProjectionPermission(PluginCall call, ActivityResult result) {
        if (call == null) return;
        if (result.getResultCode() != Activity.RESULT_OK || result.getData() == null) {
            pendingCall = null;
            call.reject("Permiso de captura cancelado.");
            return;
        }
        try {
            Context context = getContext();
            serviceReadyReceiver = new BroadcastReceiver() {
                @Override public void onReceive(Context ctx, Intent intent) {
                    unregisterReadyReceiver();
                    beginProjection(call, result.getResultCode(), result.getData());
                }
            };
            IntentFilter filter = new IntentFilter(ScreenCaptureForegroundService.ACTION_READY);
            if (Build.VERSION.SDK_INT >= 33) {
                context.registerReceiver(serviceReadyReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
            } else {
                context.registerReceiver(serviceReadyReceiver, filter);
            }
            receiverRegistered = true;
            Intent serviceIntent = new Intent(context, ScreenCaptureForegroundService.class);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(serviceIntent);
            else context.startService(serviceIntent);
        } catch (Exception e) {
            unregisterReadyReceiver();
            cleanup();
            pendingCall = null;
            call.reject("No se pudo iniciar el servicio de captura: " + e.getMessage());
        }
    }

    private void beginProjection(PluginCall call, int resultCode, Intent permissionData) {
        if (pendingCall != call) return;
        try {
            MediaProjectionManager manager = (MediaProjectionManager)
                    getContext().getSystemService(Context.MEDIA_PROJECTION_SERVICE);
            projection = manager.getMediaProjection(resultCode, permissionData);
            if (projection == null) throw new IllegalStateException("Android no concedió la captura.");

            WindowManager wm = (WindowManager) getContext().getSystemService(Context.WINDOW_SERVICE);
            DisplayMetrics metrics = new DisplayMetrics();
            wm.getDefaultDisplay().getRealMetrics(metrics);
            int width = metrics.widthPixels;
            int height = metrics.heightPixels;
            int density = metrics.densityDpi;

            reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 3);
            projection.registerCallback(new MediaProjection.Callback() {
                @Override public void onStop() {
                    cleanupDisplayAndReader();
                }
            }, handler);
            display = projection.createVirtualDisplay("PortalConductorCapture", width, height, density,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.getSurface(), null, handler);
            handler.postDelayed(() -> readFrame(call), 700);
        } catch (Exception e) {
            cleanup();
            pendingCall = null;
            call.reject("No se pudo capturar la pantalla: " + e.getMessage());
        }
    }

    private void readFrame(PluginCall call) {
        if (pendingCall != call || reader == null) return;
        Image image = null;
        Bitmap padded = null;
        Bitmap bitmap = null;
        try {
            image = reader.acquireLatestImage();
            if (image == null) {
                handler.postDelayed(() -> readFrame(call), 250);
                return;
            }
            Image.Plane plane = image.getPlanes()[0];
            ByteBuffer buffer = plane.getBuffer();
            int pixelStride = plane.getPixelStride();
            int rowStride = plane.getRowStride();
            int rowPadding = rowStride - pixelStride * image.getWidth();
            padded = Bitmap.createBitmap(image.getWidth() + rowPadding / pixelStride,
                    image.getHeight(), Bitmap.Config.ARGB_8888);
            padded.copyPixelsFromBuffer(buffer);
            bitmap = Bitmap.createBitmap(padded, 0, 0, image.getWidth(), image.getHeight());
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.JPEG, 90, out);
            JSObject response = new JSObject();
            response.put("base64", Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP));
            response.put("mimeType", "image/jpeg");
            call.resolve(response);
            cleanup();
            pendingCall = null;
        } catch (Exception e) {
            cleanup();
            pendingCall = null;
            call.reject("Error leyendo la captura: " + e.getMessage());
        } finally {
            if (image != null) image.close();
            if (bitmap != null && !bitmap.isRecycled()) bitmap.recycle();
            if (padded != null && !padded.isRecycled()) padded.recycle();
        }
    }

    private void unregisterReadyReceiver() {
        if (receiverRegistered && serviceReadyReceiver != null) {
            try { getContext().unregisterReceiver(serviceReadyReceiver); } catch (Exception ignored) {}
        }
        receiverRegistered = false;
        serviceReadyReceiver = null;
    }

    private void cleanupDisplayAndReader() {
        if (display != null) { display.release(); display = null; }
        if (reader != null) { reader.close(); reader = null; }
    }

    private void cleanup() {
        unregisterReadyReceiver();
        cleanupDisplayAndReader();
        if (projection != null) {
            try { projection.stop(); } catch (Exception ignored) {}
            projection = null;
        }
        try { getContext().stopService(new Intent(getContext(), ScreenCaptureForegroundService.class)); }
        catch (Exception ignored) {}
    }

    @Override
    protected void handleOnDestroy() {
        cleanup();
        super.handleOnDestroy();
    }
}
